#scenario
"""
Scenario selection page

"""
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Button, Label
from textual.containers import Vertical

class Scenario(ComposeResult):
    pass
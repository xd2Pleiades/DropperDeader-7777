#character_creation.py
"""
Character creation page

"""
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Button, Label
from textual.containers import Vertical

class CharacterCreation(Screen):
    pass
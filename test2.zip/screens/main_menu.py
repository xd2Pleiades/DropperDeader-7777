#main_menu
"""
Main Menu UIX
"""
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Button, Label
from textual.containers import Vertical


class MainMenu(Screen):
    CSS = """
    Screen {
        align: center middle;
    }

    #menu {
        height: auto;
        width: 60;
        margin: 4 8;
        background: $panel;
        border: tall $background;
        padding: 1 2;
    }

    #title {
        text-style: bold;
        text-align: center;
        width: 100%;
        margin-bottom: 1;
    }

    #lore {
        text-align: center;
        width: 100%;
        margin-bottom: 2;
    }

    Button {
        width: 100%;
        margin-top: 1;
    }
    """

    BINDINGS = [("d", "toggle_dark", "Toggle dark mode")]

    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical(id="menu"):
            yield Label("Welcome to DropperDeader:7777", id="title")
            yield Label(
                "You were born around the year 7777, either you choose or not. You are a human that is single living none for other themselves. In Karo a freezing and unclean planet, you are a part of a 53 trillion subpopulation that the Federation has not taken care of. You are apart of a many, that are trampled under its grimy boots. You found none but other yourself.",
                id="lore"
            )
            yield Button("Play", id="play")
            yield Button("Quit", id="quit")
        yield Footer()

    def action_toggle_dark(self) -> None:
        self.app.theme = (
            "textual-dark" if self.app.theme == "textual-light" else "textual-light"
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "play":
            self.notify("Those who moved forward with the stars... Seek a new hell.")
            self.app.switch_screen("scenario")
        elif event.button.id == "quit":
            self.app.exit()